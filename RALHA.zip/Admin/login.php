<?php
session_start();

// Konfigurasi koneksi database
$host = 'localhost';
$dbUsername = 'root'; // Ganti dengan username database Anda
$dbPassword = ''; // Ganti dengan password database Anda
$dbName = 'ralha_db';

// Membuat koneksi ke database
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Periksa koneksi
if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}

// Periksa apakah pengguna sudah login
if (isset($_SESSION['username'])) {
    header('Location: index.php'); // Jika sudah login, langsung ke dashboard
    exit();
}

// Proses login jika form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);

    // Query untuk memeriksa pengguna
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = MD5('$password')";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        // Set sesi pengguna
        $_SESSION['username'] = $username;

        // Redirect ke dashboard
        header('Location: index.php');
        exit();
    } else {
        $errorMessage = "Invalid username or password.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('https://th.bing.com/th/id/OIP.wgv3Nhv4VEv86dsVx3ZCTwHaEK?w=297&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h3 {
            font-family: 'Arial', sans-serif;
            font-weight: bold;
        }
    </style>

</head>
<body>
    <div class="login-card">
        <h3 class="text-center mb-4">Admin Login</h3>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
                        <a href="daftar.php">Daftar</a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

        </form>
        <?php if (isset($errorMessage)): ?>
            <div class="text-danger text-center mt-3"><?= htmlspecialchars($errorMessage) ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
