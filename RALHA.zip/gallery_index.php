<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Website RALHA</title>
  <body style="text-align:center">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Travel</title>
    <link rel="stylesheet" href="gallery.css" />
  </head>
  <body>
    <nav>
      <div class="layar-dalam">
        <div class="logo">
          <a href=""><img src="Keperluan/drive-download-20241009T003620Z-001/LOGO 1.png" class="putih" /></a>
          <a href=""><img src="Keperluan/drive-download-20241009T003620Z-001/LOGO 1.png" class="hitam" /></a>
        </div>
        <div class="menu">
          <a href="#" class="tombol-menu">
            <span class="garis"></span>
            <span class="garis"></span>
            <span class="garis"></span>
          </a>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#aboutus">About</a></li>
            <li><a href="#booking">Booking</a></li>
            <li><a href="#gallery">Gallery</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <section class="abuabu" id="blog">
          <div class="layar-dalam">
            <h3>Gallery Destinasi</h3>
            <p class="ringkasan">
            Beberapa Destinasi Eksotis di Indonesia yang Wajib Dikunjungi.
            </p>
            <div class="blog">
              <div class="area">
                <div
                  class="gambar"
                  style="background-image: url('Keperluan/drive-download-20241009T003620Z-001/Banda Neira.jpg')"
                ></div>
                <div class="text">
                  <article>
                    <h4><a href="#">Tahukah anda, wisata Banda Neira?</a></h4>
                    <p>
                        Banda Neira merupakan destinasi wisata yang cocok bagi kamu yang mencari ketenangan, 
                        keindahan alam, dan pengalaman budaya yang unik. Jangan lewatkan kesempatan untuk mengunjungi 
                        surga tersembunyi di Timur Indonesia ini!
                    </p>
                  </article>
                </div>
              </div>
              <div class="area">
                <div
                  class="gambar"
                  style="background-image: url('Keperluan/drive-download-20241009T003620Z-001/Raja Ampat.jpg')"
                ></div>
                <div class="text">
                  <article>
                    <h4><a href="#">Tahukah anda, wisata Raja ampat?</a></h4>
                    <p>
                        Raja Ampat merupakan destinasi wisata yang wajib kamu kunjungi jika kamu ingin merasakan keindahan alam yang 
                        sesungguhnya. Dengan keanekaragaman hayati yang tinggi, pulau-pulau yang eksotis, dan aktivitas yang seru, Raja
                         Ampat akan memberikan pengalaman liburan yang tak terlupakan.
                    </p>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </section>
      <footer id="contact">
        <div class="layar-dalam">
          <div>
            <h5>Info</h5>
            Menyediakan informasi dan layanan perjalanan, seperti pemesanan tiket, reservasi hotel, panduan destinasi, 
            dan tips perjalanan untuk membantu pengguna merencanakan perjalanan dengan mudah
          </div>
          <div>
            <h5>Contact</h5>
            Jika Anda memiliki pertanyaan atau saran tentang layanan kami, hubungi kami. 
            Kami siap membantu Anda merencanakan perjalanan yang sempurna!
          </div>
          <div>
            <h5>Help</h5>
            Kami siap membantu Anda menghadapi tantangan perjalanan. Jika butuh bantuan lebih, hubungi tim dukungan kami 
          </div>
          <div>
            <h5>Stay Connected</h5>
            Kami ingin Anda mendapatkan informasi terkini dan penawaran menarik tentang perjalanan. 
            Bergabunglah dengan komunitas kami agar tetap terhubung dan mendapatkan info terbaru
          </div>
        </div>
        <div class="layar-dalam">
          <div class="copyright">&copy; 2024 Travelling Indonesia</div>
        </div>
      </footer>
    </div>
    <script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
    <script src="gallery.js"></script>
  </body>