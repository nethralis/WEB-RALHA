<?php
session_start();
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran User - RALHA</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('https://th.bing.com/th/id/OIP.gAWBM8XkdDtgWQSZnwE-mwHaEJ?w=322&h=181&c=7&r=0&o=5&dpr=1.3&pid=1.7');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: rgba(0,0,0,0.5);
        }

        .register-container {
            background-color: rgba(255,255,255,0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
        }

        .register-container h3 {
            color: #333;
            margin-bottom: 20px;
        }

        .register-form table {
            width: 100%;
        }

        .register-form td {
            padding: 5px;
        }

        .register-form input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .register-form button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .register-form button:hover {
            background-color: #218838;
        }

        .register-form a {
            color: #007bff;
            text-decoration: none;
            margin-left: 10px;
        }

        .register-form a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <form method="post" class="register-form">
            <h3>Pendaftaran User</h3>
            <table>
                <tr>
                    <td>Nama</td>
                    <td><input type="text" name="nama" required></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <button type="submit">Daftar</button>
                        <a href="login.php">Login</a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <?php
    if(isset($_POST['username'])) { 
        $nama = $_POST['nama'];
        $username = $_POST['username'];
        $password = $_POST['password']; // Catatan: Sebaiknya gunakan password_hash()

        $query = mysqli_query($koneksi, "INSERT INTO user(nama, username, password) values('$nama', '$username', '$password')");
        if($query){
            echo '<script>alert("Selamat, pendaftaran anda berhasil. Silahkan kembali ke menu login."); window.location.href="login.php";</script>';
        }else{
            echo '<script>alert("Pendaftaran gagal.");</script>';
        }
    }
    ?>
</body>
</html>