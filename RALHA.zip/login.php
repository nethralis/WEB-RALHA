<?php
session_start();
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login ke Website RALHA</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('https://cdn-2.tstatic.net/batam/foto/bank/images/ilustrasi-pesawat-garuda-indonesia.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: rgba(0,0,0,0.5);
        }

        .login-container {
            background-color: rgba(255,255,255,0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
        }

        .login-container h3 {
            color: #333;
            margin-bottom: 20px;
        }

        .login-form table {
            width: 100%;
        }

        .login-form input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-form button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .login-form button:hover {
            background-color: #0056b3;
        }

        .login-form a {
            color: #007bff;
            text-decoration: none;
            margin-left: 10px;
        }

        .login-form a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <form method="post" class="login-form">
            <h3>Login User</h3>
            <table>
                <tr>
                    <td colspan="2">
                        <input type="text" name="username" placeholder="Username" required>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="password" name="password" placeholder="Password" required>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <button type="submit">Login</button>
                        <a href="daftar.php">Daftar</a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <?php
    if(isset($_POST["username"])){
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        $query = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$username' AND password = '$password'");
        
        if(mysqli_num_rows($query) > 0){
            $data = mysqli_fetch_array($query);
            $_SESSION['user'] = $data;
            echo '<script>alert("Selamat Datang, '.$data['nama'].'"); 
            location.href="index.php";</script>';

        }else{
            echo '<script>alert("Username/Password tidak sesuai.");</script>';
        }
    }
    ?>
</body>
</html>