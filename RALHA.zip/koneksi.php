<?php
$koneksi = mysqli_connect("localhost", "root", "","db_admin") or die ('database tidak terhubung');
?>