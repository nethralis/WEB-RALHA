<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ralha_db";

$conn = new mysqli($servername, $username, $password, $ralha_db);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
