<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ralha_database";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

// Fetch ticket bookings
$sql = "SELECT tb.id, l1.name AS origin, l2.name AS destination, tb.departure_date, tb.return_date, tb.passenger_count 
       FROM ralha_database tb 
       JOIN locations l1 ON tb.origin_id = l1.id 
       JOIN locations l2 ON tb.destination_id = l2.id"; 
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Panel - Pemesanan Tiket</title>
   <link rel="stylesheet" href="styles.css">
</head>
<body>
   <h1>Admin Panel - Pemesanan Tiket</h1>
   <button id="fetchData">Tampilkan Data</button>
   <table>
       <thead>
           <tr>
               <th>ID</th>
               <th>Lokasi Asal</th>
               <th>Lokasi Tujuan</th>
               <th>Tanggal Keberangkatan</th>
               <th>Tanggal Kembali</th>
               <th>Penumpang</th>
               <th>Aksi</th>
           </tr>
       </thead>
       <tbody id="ticketTableBody">
           <?php
           if ($result->num_rows > 0) {
               while($row = $result->fetch_assoc()) {
                   echo "<tr>
                           <td>{$row['id']}</td>
                           <td>{$row['origin']}</td>
                           <td>{$row['destination']}</td>
                           <td>{$row['departure_date']}</td>
                           <td>{$row['return_date']}</td>
                           <td>{$row['passenger_count']}</td>
                           <td>
                               <button onclick='editTicket({$row['id']})'>Edit</button>
                               <button onclick='deleteTicket({$row['id']})'>Hapus</button>
                           </td>
                         </tr>";
               }
           } else {
               echo "<tr><td colspan='7'>No data available</td></tr>";
           }
           $conn->close();
           ?>
       </tbody>
   </table>

   <script src="script.js"></script>
</body>
</html>