<?php
// Start session
session_start();

// Koneksi ke database
$mysqli = new mysqli("localhost", "root", "", "ralha_database");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Handle actions (delete, edit, add)
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id = $_GET['id'] ?? null;

    if ($action == 'delete' && $id) {
        $mysqli->query("DELETE FROM user WHERE id_user = '$id'");
        header("Location: dashboard.php");
        exit;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    if (isset($_POST['id']) && $_POST['id']) {
        // Update existing record
        $id = $_POST['id'];
        $mysqli->query("UPDATE user SET nama = '$name', username = '$username', password = '$password' WHERE id_user = $id");
    } else {
        // Insert new record
        $mysqli->query("INSERT INTO user (nama, username, password) VALUES ('$name', '$username', '$password')");
    }
    header("Location: dashboard.php");
    exit;
}

// Fetch users data
$users = $mysqli->query("SELECT * FROM user");
if (!$users) {
    die("Query Error: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* Global Style */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }
        h1, h2 {
            text-align: center;
            color: #4CAF50;
        }
        a {
            text-decoration: none;
            color: white;
        }
        a:hover {
            opacity: 0.8;
        }
        button, input[type="text"], input[type="password"] {
            font-size: 14px;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }

        /* Form Section */
        form {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }

        /* Table Section */
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        td a {
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            margin-right: 5px;
        }
        td a:hover {
            background-color: #0056b3;
        }
        td a.delete {
            background-color: #DC3545;
        }
        td a.delete:hover {
            background-color: #a71d2a;
        }
    </style>
</head>
<body>
    <h1>Web Admin</h1>

    <h2>Add / Edit User</h2>
    <form method="POST" action="dashboard.php">
        <input type="hidden" name="id" value="<?= $_GET['edit'] ?? '' ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= $_GET['name'] ?? '' ?>" required>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?= $_GET['username'] ?? '' ?>" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Save</button>
    </form>

    <h2>User List</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Username</th>
                <th>Password (Hashed)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $users->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['id_user'] ?></td>
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['username'] ?></td>
                    <td><?= $row['password'] ?></td>
                    <td>
                        <a href="?edit=<?= $row['id_user'] ?>&name=<?= $row['nama'] ?>&username=<?= $row['username'] ?>">Edit</a>
                        <a class="delete" href="?action=delete&id=<?= $row['id_user'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
