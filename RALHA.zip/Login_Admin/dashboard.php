<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <h1>Dashboard Admin</h1>
    <a href="bookings.php">Lihat Pemesanan</a>
    <a href="logout.php">Logout</a>
</body>
</html>